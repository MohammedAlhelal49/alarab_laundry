$( document ).ready(function() {
passwordToggle();
handleFileInput();
formUpdateLink();
inputDateHandle();

    $('.page-fade-animate').css('opacity', 1);
});

function inputDateHandle () {
    $('.text-input-date-picker').datepicker({
                dateFormat: 'dd/mm/yy'
            });


                       $('.handle-server-date-formate').each(function(){
                // Get the current date value
                var currentDateValue = $(this).val();

                // Split the date into parts
                var dateParts = currentDateValue.split('-');

                // Create a new Date object with the parts
                var dateObject = new Date(dateParts[0], dateParts[1] - 1, dateParts[2]);

                // Format the date as dd/mm/yyyy
                var formattedDate = ('0' + dateObject.getDate()).slice(-2) + '/' + ('0' + (dateObject.getMonth() + 1)).slice(-2) + '/' + dateObject.getFullYear();

                // Set the new formatted date value to the element
                $(this).val(formattedDate);
            });





}

function passwordToggle () {
$("form input[type|='password']").next().on('click' , function () {
 let $type = $(this).prev().attr( "type" );
  if ($type == 'password') {
    $(this).prev().attr( "type" , "text" );
    $(this).removeClass("fa-eye").addClass('fa-eye-slash');
  }
  else {
   $(this).prev().attr( "type" , "password" );
     $(this).removeClass("fa-eye-slash").addClass('fa-eye');
  }
})
}

function removeSubstring(str, substrToRemove) {
  const index = str.indexOf(substrToRemove);
  if (index !== -1) {
    return str.slice(0, index) + str.slice(index + substrToRemove.length);
  }
  return str;
}

function handleFileInput () {
// enable clear file value
$('.file-field-container .clear-icon').on('click' , function () {
$(this).next().val('');
})

// enable update file value
$('.file-update-trigger').on('click' , function () {
$(this).parent().parent().removeClass("update-file-holder")
$(this).parent().next().next().css("visibility", "visible")
$(this).parent().next().css("visibility", "visible")
$(this).css("display" , "none")
})
}

function formUpdateLink () {
var element = $('.form-update-link')
element.on('click' , function (event) {
      event.preventDefault();
      window.location.href = element.attr('href');
})
}





